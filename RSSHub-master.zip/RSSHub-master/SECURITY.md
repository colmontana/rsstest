# Security Policy

## Supported Version

Latest commits in master branch

## Reporting a Vulnerability

If you believe you have found a security vulnerability in RSSHub, please let us know right away, you can [open a draft security advisory](https://github.com/DIYgod/RSSHub/security/advisories/new) or email us at [i@diygod.me](mailto:i@diygod.me). We will investigate all legitimate reports and do our best to quickly fix the problem.
