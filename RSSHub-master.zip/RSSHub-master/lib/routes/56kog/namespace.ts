import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '明月中文网',
    url: '56kog.com',
};
