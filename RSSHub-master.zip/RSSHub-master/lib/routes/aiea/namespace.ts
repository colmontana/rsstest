import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Asian Innovation and Entrepreneurship Association',
    url: 'www.aiea.org',
};
