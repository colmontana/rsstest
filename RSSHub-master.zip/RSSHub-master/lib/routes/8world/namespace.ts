import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '8 视界',
    url: '8world.com',
};
