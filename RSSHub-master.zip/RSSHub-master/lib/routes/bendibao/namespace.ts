import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '本地宝',
    url: 'bendibao.com',
};
