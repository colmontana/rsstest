const rootUrl = 'https://www.agemys.org';

export { rootUrl };
