import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Автоцентр.ua',
    url: 'autocentre.ua',
    description: 'Автоцентр.ua: автоновини - Автомобільний сайт N1 в Україні',
};
