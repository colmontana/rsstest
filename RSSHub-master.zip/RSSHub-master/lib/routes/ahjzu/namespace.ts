import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '安徽建筑大学',
    url: 'news.ahjzu.edu.cn',
};
