import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '78 动漫',
    url: '78dm.net',
};
