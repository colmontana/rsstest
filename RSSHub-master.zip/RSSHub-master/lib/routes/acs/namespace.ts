import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Unknown',
    url: 'pubs.acs.org',
};
