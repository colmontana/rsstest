import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'BBC',
    url: 'bbc.com',
};
