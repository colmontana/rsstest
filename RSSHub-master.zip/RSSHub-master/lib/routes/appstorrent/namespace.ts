import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AppsTorrent',
    url: 'appstorrent.ru',
};
