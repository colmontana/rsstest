import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Wojciech Muła',
    url: '0x80.pl',
    description: '',
};
