import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Aqara',
    url: 'aqara.com',
};
