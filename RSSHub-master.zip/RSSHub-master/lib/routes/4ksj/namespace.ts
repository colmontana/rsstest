import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '4k 世界',
    url: '4ksj.com',
};
