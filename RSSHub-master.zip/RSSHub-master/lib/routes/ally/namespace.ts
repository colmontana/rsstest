import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '艾莱资讯',
    url: 'rail.ally.net.cn',
};
