import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '链新闻 ABMedia',
    url: 'www.abmedia.io',
};
