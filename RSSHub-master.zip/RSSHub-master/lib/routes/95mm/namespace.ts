import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'MM 范',
    url: '95mm.org',
};
