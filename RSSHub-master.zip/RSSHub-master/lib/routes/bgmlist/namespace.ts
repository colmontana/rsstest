import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '番组放送',
    url: 'bgmlist.com',
};
