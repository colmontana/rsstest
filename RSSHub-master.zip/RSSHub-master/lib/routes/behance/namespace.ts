import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Behance',
    url: 'www.behance.net',
};
