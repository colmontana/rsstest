import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '爆料公社',
    url: 'web.bc3ts.net',
    categories: ['new-media'],
};
