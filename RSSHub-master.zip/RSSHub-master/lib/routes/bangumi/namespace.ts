import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'アニメ新番組',
    url: 'bangumi.moe',
};
