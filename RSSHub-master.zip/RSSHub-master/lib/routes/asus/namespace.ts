import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ASUS',
    url: 'asus.com.cn',
};
