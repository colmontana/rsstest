import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '百度',
    url: 'www.baidu.com',
};
