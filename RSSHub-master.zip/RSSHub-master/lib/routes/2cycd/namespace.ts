import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '二次元虫洞',
    url: '2cycd.com',
};
