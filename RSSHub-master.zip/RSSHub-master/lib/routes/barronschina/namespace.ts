import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '巴伦周刊中文版',
    url: 'barronschina.com.cn',
};
