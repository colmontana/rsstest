import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'biodiscover.com 生物探索',
    url: 'www.biodiscover.com',
};
