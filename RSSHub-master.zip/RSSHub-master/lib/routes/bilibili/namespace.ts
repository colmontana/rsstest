import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '哔哩哔哩 bilibili',
    url: 'www.bilibili.com',
};
