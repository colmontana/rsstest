import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '中华全国专利代理师协会',
    url: 'acpaa.cn',
};
