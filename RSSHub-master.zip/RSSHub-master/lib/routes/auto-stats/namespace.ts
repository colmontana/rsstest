import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '中国汽车工业协会统计信息网',
    url: 'auto-stats.org.cn',
};
