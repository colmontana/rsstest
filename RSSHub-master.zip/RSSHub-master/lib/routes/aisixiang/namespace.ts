import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '爱思想',
    url: 'aisixiang.com',
};
