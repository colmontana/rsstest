import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '一亩三分地',
    url: 'blog.1point3acres.com',
};
