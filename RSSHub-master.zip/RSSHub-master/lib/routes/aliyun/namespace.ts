import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '阿里云',
    url: 'developer.aliyun.com',
};
