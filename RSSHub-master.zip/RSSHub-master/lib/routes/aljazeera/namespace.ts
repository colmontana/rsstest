import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Aljazeera 半岛电视台',
    url: 'aljazeera.com',
};
