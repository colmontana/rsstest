import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '4Gamers',
    url: 'www.4gamers.com.tw',
};
