import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Arcteryx',
    url: 'arcteryx.com',
};
