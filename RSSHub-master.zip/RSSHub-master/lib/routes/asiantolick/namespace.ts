import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Asian to lick',
    url: 'asiantolick.com',
};
