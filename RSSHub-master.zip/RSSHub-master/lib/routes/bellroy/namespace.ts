import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Bellroy',
    url: 'bellroy.com',
};
