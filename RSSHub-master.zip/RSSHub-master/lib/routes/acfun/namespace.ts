import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AcFun',
    url: 'www.acfun.cn',
};
