import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '北京市科学技术协会',
    url: 'bast.net.cn',
};
