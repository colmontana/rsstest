import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '北京价格',
    url: 'beijingprice.cn',
    categories: ['government'],
    description: '',
};
