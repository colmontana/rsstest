import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AEON',
    url: 'aeon.aeon.co',
};
