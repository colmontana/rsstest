import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '論盡媒體 AllAboutMacau Media',
    url: 'aamacau.com',
};
