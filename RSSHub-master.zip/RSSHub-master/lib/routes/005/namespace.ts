import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '幻之羁绊动漫网',
    url: '005.tv',
    categories: ['anime'],
    description: '',
};
