import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Apple',
    url: 'apps.apple.com',
};
