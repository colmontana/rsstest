import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'BigQuant',
    url: 'bigquant.com',
};
