import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '阿基米德 FM',
    url: 'm.ajmide.com',
};
