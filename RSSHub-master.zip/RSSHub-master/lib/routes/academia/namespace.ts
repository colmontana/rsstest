import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Academia',
    url: 'https://www.academia.edu/',
};
