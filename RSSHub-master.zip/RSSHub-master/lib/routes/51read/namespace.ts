import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '51Read',
    url: 'm.51read.org',
};
