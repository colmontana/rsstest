import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Binance',
    url: 'binance.com',
};
