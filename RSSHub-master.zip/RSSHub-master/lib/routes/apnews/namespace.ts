import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AP News',
    url: 'apnews.com',
};
