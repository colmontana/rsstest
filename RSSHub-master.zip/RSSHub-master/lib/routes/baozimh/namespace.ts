import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '包子漫画',
    url: 'www.baozimh.com',
};
