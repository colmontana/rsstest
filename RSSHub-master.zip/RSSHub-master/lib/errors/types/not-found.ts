class NotFoundError extends Error {
    name = 'NotFoundError';
}

export default NotFoundError;
